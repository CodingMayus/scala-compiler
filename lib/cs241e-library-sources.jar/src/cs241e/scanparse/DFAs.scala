/*
   Copyright 2026 Ondrej Lhotak. All rights reserved.

   Permission is granted for private study use by students registered in
   CS 241E in the Fall 2026 term.

   The contents of this file may not be published, in whole or in part,
   in print or electronic form.

   The contents of this file may be included in work submitted for CS
   241E assignments in Fall 2026. The contents of this file may not be
   submitted, in whole or in part, for credit in any other course.
*/
package cs241e.scanparse

object DFAs {

  /** For convenience, we generally use `String`s to denote DFA states, but here we create a type alias
    * so that we can use the type `State` when we mean a DFA state. The Scala compiler will treat the
    * type `State` the same as if we had used the type `String` instead.
    */
  type State = String

  /** A representation of a deterministic finite automaton (DFA). */
  case class DFA( alphabet: Set[Char],
                  states: Set[State],
                  start: State,
                  accepting: Set[State],
                  transition: PartialFunction[(State, Char), State]
                  )

  /** A token that has been produced as the output of a scanner.
    * @param kind   is set to the accepting state of the scanning DFA that accepted the token.
    * @param lexeme is the string of actual characters that make up the token in the input to the scanner.
    */
  case class Token(kind: String, lexeme: String = "") {
    override def toString = kind + " " + lexeme
  }
}
