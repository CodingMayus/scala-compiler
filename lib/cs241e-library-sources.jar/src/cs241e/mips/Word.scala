/*
   Copyright 2026 Ondrej Lhotak. All rights reserved.

   Permission is granted for private study use by students registered in
   CS 241E in the Fall 2026 term.

   The contents of this file may not be published, in whole or in part,
   in print or electronic form.

   The contents of this file may be included in work submitted for CS
   241E assignments in Fall 2026. The contents of this file may not be
   submitted, in whole or in part, for credit in any other course.
*/
package cs241e.mips
import cs241e.Utils.*

/** A representation of a 32-bit sequence of bits. */
trait Word extends Seq[Boolean] {
  override val length = 32
}

object Word {
  /** Create a word from a string.
    * Precondition: forall i. 0 <= i < bits.length ==> bits(i) == '0' || bits(i) == '1' || bits(i) == ' '
    * Precondition: bits.filter(bit => bit != ' ').size == 32
    */
  def apply(bits: String): Word = implementation.Word(bits)

  /** Create a word from a sequence of bits.
    * Precondition: bits.length == 32.
    */
  def apply(bits: Seq[Boolean]): Word = implementation.Word(bits)

  /** The word of 32 zero bits. Scala note: "0" * 32 is shorthand for "00000000000000000000000000000000".
    */
  val zero = Word("0" * 32)
}
