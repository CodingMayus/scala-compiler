/*
   Copyright 2026 Ondrej Lhotak. All rights reserved.

   Permission is granted for private study use by students registered in
   CS 241E in the Fall 2026 term.

   The contents of this file may not be published, in whole or in part,
   in print or electronic form.

   The contents of this file may be included in work submitted for CS
   241E assignments in Fall 2026. The contents of this file may not be
   submitted, in whole or in part, for credit in any other course.
*/
package cs241e.mips

/** A representation of the state of the MIPS CPU and memory. */
abstract class State {
  /** Read the value of register `number`. */
  def reg(number: Long): Word
  /** Read the value at memory address `address`. */
  def mem(address: Word): Word
  /** Set the value of register `number` to `word`. */
  def setReg(number: Long, word: Word): State
  /** Set the value at memory address `address` to `word`. */
  def setMem(address: Word, word: Word): State
}

object State {
  /** The special program counter register. */
  val PC = 32L
  /** The special register holding the low-order 32 bits of a multiplication or the quotient of a division. */
  val LO = 33L
  /** The special register holding the high-order 32 bits of a multiplication or the remainder of a division. */
  val HI = 34L
  /** Returns the initial state of the CPU. */
  def apply(): State = implementation.State().setReg(31, CPU.terminationPC).setReg(30, CPU.maxAddr)
}
