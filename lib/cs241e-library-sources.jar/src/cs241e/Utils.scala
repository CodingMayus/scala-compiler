/*
   Copyright 2026 Ondrej Lhotak. All rights reserved.

   Permission is granted for private study use by students registered in
   CS 241E in the Fall 2026 term.

   The contents of this file may not be published, in whole or in part,
   in print or electronic form.

   The contents of this file may be included in work submitted for CS
   241E assignments in Fall 2026. The contents of this file may not be
   submitted, in whole or in part, for credit in any other course.
*/
package cs241e

object Utils {
  /** Given `power`, computes 2^`power`^. */
  def twoTo(power: Int): Long = (1L<<power)

  /** Given a `number`, finds a `result` congruent to it modulo 2^32^ and within the
    * range -2^31^ to 2^31^-1 (inclusive).
    */
  def mod2to32signed(number: Long): Long = mod2to32Range(number, -Utils.twoTo(31))

  /** Given a `number`, finds a `result` congruent to it modulo 2^32^ and within the
    * range 0 to 2^32^-1 (inclusive).
    */
  def mod2to32(number: Long): Long = mod2to32Range(number, 0)

  /** Given a `number`, finds a `result` congruent to it modulo 2^32^ and within the
    * range `rangeStart` to `rangeStart`+2^32^-1 (inclusive).
    */
  private def mod2to32Range(number: Long, rangeStart: Long): Long = {
    var remainder = number % Utils.twoTo(32)
    while(remainder < rangeStart) remainder += Utils.twoTo(32)
    while(remainder >= rangeStart + Utils.twoTo(32)) remainder -= Utils.twoTo(32)
    remainder
  } ensuring(result =>
    (result - number) % Utils.twoTo(32) == 0
      && result >= rangeStart
      && result < rangeStart + Utils.twoTo(32)
  )

  /** Enables a `Seq` to be split into multiple `Seq`s at a list of offsets. */
  extension[A](seq: Seq[A]) {
    /** Splits a `Seq` into multiple `Seq`s of a list of lengths `is`.
      * Example: `Seq(1,2,3,4,5).splitAt(List(2,1)) == List(Seq(1,2), Seq(3), Seq(4,5))`
      */
    def splitAt(is: List[Int]): List[Seq[A]] = is match {
      case ihead :: itail =>
        val (head, tail) = seq.splitAt(ihead)
        head :: tail.splitAt(itail)
      case Nil => List(seq)
    }
  }

  def impossible(reason: String = ""): Nothing = {
    throw new RuntimeException(reason)
  }
}
